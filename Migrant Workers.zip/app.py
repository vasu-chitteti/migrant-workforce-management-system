from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3, os, hashlib, uuid, random, string
from datetime import datetime, date, timedelta
from functools import wraps
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = 'migrant_workforce_secret_2024'
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
DB_PATH = 'database.db'

SMTP_HOST = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USER = 'way2track01@gmail.com'
SMTP_PASSWORD = 'masvczanrdbufpuq'
SMTP_FROM = 'MigrantWorks <masvczanrdbufpuq>'
OTP_EXPIRY_MINUTES = 10

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(f): return '.' in f and f.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

def rows_to_dicts(rows):
    """Convert SQLite Row objects to plain dicts for JSON serialization."""
    return [dict(r) for r in rows]

def row_to_dict(row):
    """Convert single SQLite Row to dict, or return None."""
    return dict(row) if row else None
def get_db():
    c = sqlite3.connect(DB_PATH); c.row_factory = sqlite3.Row; return c
def hash_password(p): return hashlib.sha256(p.encode()).hexdigest()
def generate_otp(n=6): return ''.join(random.choices(string.digits, k=n))

def send_otp_email(to_email, otp, purpose='KYC Verification'):
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = f'MigrantWorks OTP — {otp}'
        msg['From'] = SMTP_FROM; msg['To'] = to_email
        html = f"""<html><body style="font-family:sans-serif;background:#F4F6FA;padding:20px">
        <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden">
        <div style="background:#0A1628;padding:24px;text-align:center">
        <div style="color:#FF6B00;font-size:1.5rem;font-weight:700">MigrantWorks</div>
        <div style="color:rgba(255,255,255,.5);font-size:.75rem">Workforce Management System</div></div>
        <div style="padding:30px"><h3 style="color:#0A1628">{purpose}</h3>
        <p style="color:#6B7280">Your OTP (valid {OTP_EXPIRY_MINUTES} mins):</p>
        <div style="background:#FFF8F0;border:2px dashed #FF6B00;border-radius:10px;padding:20px;text-align:center;margin:20px 0">
        <span style="font-size:2.5rem;font-weight:700;color:#FF6B00;letter-spacing:10px;font-family:monospace">{otp}</span></div>
        <p style="color:#dc2626;font-size:.82rem">Do not share this OTP. If not requested, ignore this email.</p></div></div>
        </body></html>"""
        msg.attach(MIMEText(f"MigrantWorks OTP: {otp} (valid {OTP_EXPIRY_MINUTES} mins)", 'plain'))
        msg.attach(MIMEText(html, 'html'))
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            s.ehlo(); s.starttls(); s.login(SMTP_USER, SMTP_PASSWORD)
            s.sendmail(SMTP_USER, to_email, msg.as_string())
        return True, 'OTP sent'
    except smtplib.SMTPAuthenticationError:
        return False, 'SMTP auth failed — check credentials in config'
    except Exception as e:
        return False, str(e)

def init_db():
    conn = get_db(); c = conn.cursor()
    c.executescript('''
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL,
            email TEXT, phone TEXT, email_verified INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS workers (id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, full_name TEXT NOT NULL, dob TEXT, gender TEXT,
            aadhaar_number TEXT UNIQUE, address TEXT, state TEXT, district TEXT,
            pincode TEXT, photo_path TEXT, skill TEXT, experience_years INTEGER DEFAULT 0,
            kyc_status TEXT DEFAULT 'pending', kyc_verified_at TIMESTAMP,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'active',
            FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS contractors (id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, company_name TEXT NOT NULL, license_number TEXT UNIQUE,
            contact_person TEXT, phone TEXT, address TEXT, state TEXT,
            registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'active',
            FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS sites (id INTEGER PRIMARY KEY AUTOINCREMENT,
            contractor_id INTEGER, site_name TEXT NOT NULL, location TEXT NOT NULL,
            state TEXT, district TEXT, project_type TEXT, start_date TEXT, end_date TEXT,
            total_workers_needed INTEGER DEFAULT 0, status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(contractor_id) REFERENCES contractors(id));
        CREATE TABLE IF NOT EXISTS assignments (id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER, site_id INTEGER, contractor_id INTEGER, assigned_date TEXT,
            end_date TEXT, designation TEXT, daily_wage REAL DEFAULT 0, status TEXT DEFAULT 'active',
            FOREIGN KEY(worker_id) REFERENCES workers(id), FOREIGN KEY(site_id) REFERENCES sites(id),
            FOREIGN KEY(contractor_id) REFERENCES contractors(id));
        CREATE TABLE IF NOT EXISTS attendance (id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER, site_id INTEGER, assignment_id INTEGER,
            attendance_date TEXT NOT NULL, status TEXT DEFAULT 'present',
            check_in TEXT, check_out TEXT, hours_worked REAL DEFAULT 8, marked_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(worker_id) REFERENCES workers(id), FOREIGN KEY(site_id) REFERENCES sites(id));
        CREATE TABLE IF NOT EXISTS wages (id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER, site_id INTEGER, assignment_id INTEGER, payment_period TEXT,
            days_worked INTEGER DEFAULT 0, daily_wage REAL DEFAULT 0, total_amount REAL DEFAULT 0,
            deductions REAL DEFAULT 0, net_amount REAL DEFAULT 0, payment_date TEXT,
            payment_status TEXT DEFAULT 'pending', payment_mode TEXT, transaction_id TEXT,
            paid_by INTEGER, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(worker_id) REFERENCES workers(id), FOREIGN KEY(site_id) REFERENCES sites(id));
        CREATE TABLE IF NOT EXISTS complaints (id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER, site_id INTEGER, category TEXT, subject TEXT NOT NULL,
            description TEXT NOT NULL, status TEXT DEFAULT 'open', priority TEXT DEFAULT 'medium',
            submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, resolved_at TIMESTAMP,
            resolved_by INTEGER, resolution_notes TEXT,
            FOREIGN KEY(worker_id) REFERENCES workers(id));
        CREATE TABLE IF NOT EXISTS kyc_verifications (id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER, aadhaar_number TEXT, name_on_aadhaar TEXT, dob_on_aadhaar TEXT,
            address_on_aadhaar TEXT, verification_token TEXT, verified_status TEXT DEFAULT 'pending',
            verification_date TIMESTAMP, remarks TEXT, otp_verified INTEGER DEFAULT 0,
            FOREIGN KEY(worker_id) REFERENCES workers(id));
        CREATE TABLE IF NOT EXISTS otp_store (id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER, email TEXT NOT NULL, otp_code TEXT NOT NULL,
            purpose TEXT DEFAULT 'kyc', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP, used INTEGER DEFAULT 0, attempts INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id));
    ''')
    c.execute("SELECT id FROM users WHERE username='admin'")
    if not c.fetchone():
        c.execute("INSERT INTO users (username,password,role,email,email_verified) VALUES (?,?,?,?,?)",
                  ('admin', hash_password('admin123'), 'admin', 'admin@migrant.gov.in', 1))
    conn.commit(); conn.close()

def login_required(f):
    @wraps(f)
    def d(*a,**k):
        if 'user_id' not in session: flash('Please login first.','warning'); return redirect(url_for('login'))
        return f(*a,**k)
    return d

def role_required(*roles):
    def dec(f):
        @wraps(f)
        def d(*a,**k):
            if session.get('role') not in roles: flash('Access denied.','danger'); return redirect(url_for('dashboard'))
            return f(*a,**k)
        return d
    return dec

@app.route('/')
def index(): return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        conn=get_db(); user=conn.execute("SELECT * FROM users WHERE username=? AND password=?",(request.form['username'],hash_password(request.form['password']))).fetchone(); conn.close()
        if user:
            session.update({'user_id':user['id'],'username':user['username'],'role':user['role'],'email':user['email']})
            flash(f"Welcome back, {user['username']}!",'success'); return redirect(url_for('dashboard'))
        flash('Invalid credentials.','danger')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method=='POST':
        conn=get_db()
        try:
            conn.execute("INSERT INTO users (username,password,role,email,phone) VALUES (?,?,?,?,?)",
                (request.form['username'],hash_password(request.form['password']),request.form['role'],request.form.get('email',''),request.form.get('phone','')))
            uid=conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            if request.form['role']=='contractor':
                conn.execute("INSERT INTO contractors (user_id,company_name,contact_person,phone) VALUES (?,?,?,?)",
                    (uid,request.form.get('company_name',''),request.form['username'],request.form.get('phone','')))
            conn.commit(); flash('Registration successful! Please login.','success'); return redirect(url_for('login'))
        except sqlite3.IntegrityError: flash('Username already exists.','danger')
        finally: conn.close()
    return render_template('register.html')

@app.route('/logout')
def logout(): session.clear(); flash('Logged out.','info'); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    conn=get_db(); role=session['role']; stats={}
    if role=='admin':
        stats={k:conn.execute(q).fetchone()[0] for k,q in [
            ('workers',"SELECT COUNT(*) FROM workers"),('contractors',"SELECT COUNT(*) FROM contractors"),
            ('sites',"SELECT COUNT(*) FROM sites"),('complaints',"SELECT COUNT(*) FROM complaints WHERE status='open'"),
            ('kyc_pending',"SELECT COUNT(*) FROM workers WHERE kyc_status='pending'"),
            ('verified',"SELECT COUNT(*) FROM workers WHERE kyc_status='verified'")]}
        rw=conn.execute("SELECT w.*,u.username FROM workers w JOIN users u ON w.user_id=u.id ORDER BY w.registration_date DESC LIMIT 5").fetchall()
        rc=conn.execute("SELECT c.*,w.full_name FROM complaints c JOIN workers w ON c.worker_id=w.id ORDER BY c.submitted_at DESC LIMIT 5").fetchall()
        conn.close(); return render_template('admin_dashboard.html',stats=stats,recent_workers=rw,recent_complaints=rc)
    elif role=='contractor':
        con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
        if con:
            stats={'sites':conn.execute("SELECT COUNT(*) FROM sites WHERE contractor_id=?",(con['id'],)).fetchone()[0],
                   'workers':conn.execute("SELECT COUNT(DISTINCT worker_id) FROM assignments WHERE contractor_id=? AND status='active'",(con['id'],)).fetchone()[0],
                   'active_sites':conn.execute("SELECT COUNT(*) FROM sites WHERE contractor_id=? AND status='active'",(con['id'],)).fetchone()[0]}
        conn.close(); return render_template('contractor_dashboard.html',stats=stats,contractor=con)
    else:
        w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone(); asn=[]
        if w:
            asn=conn.execute("SELECT a.*,s.site_name,s.location FROM assignments a JOIN sites s ON a.site_id=s.id WHERE a.worker_id=? AND a.status='active'",(w['id'],)).fetchall()
            stats={'attendance':conn.execute("SELECT COUNT(*) FROM attendance WHERE worker_id=? AND status='present'",(w['id'],)).fetchone()[0],
                   'wages_paid':conn.execute("SELECT COALESCE(SUM(net_amount),0) FROM wages WHERE worker_id=? AND payment_status='paid'",(w['id'],)).fetchone()[0],
                   'complaints':conn.execute("SELECT COUNT(*) FROM complaints WHERE worker_id=?",(w['id'],)).fetchone()[0]}
        conn.close(); return render_template('worker_dashboard.html',worker=w,assignments=asn,stats=stats)

@app.route('/worker/register', methods=['GET','POST'])
@login_required
@role_required('worker')
def worker_register():
    conn=get_db(); ex=conn.execute("SELECT id FROM workers WHERE user_id=?",(session['user_id'],)).fetchone(); conn.close()
    if ex: flash('Already registered.','info'); return redirect(url_for('dashboard'))
    if request.method=='POST':
        pp=''
        if 'photo' in request.files:
            f=request.files['photo']
            if f and allowed_file(f.filename):
                fn=secure_filename(f"{uuid.uuid4()}_{f.filename}"); f.save(os.path.join(app.config['UPLOAD_FOLDER'],fn)); pp=f"uploads/{fn}"
        conn=get_db()
        try:
            conn.execute("INSERT INTO workers (user_id,full_name,dob,gender,aadhaar_number,address,state,district,pincode,photo_path,skill,experience_years) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (session['user_id'],request.form['full_name'],request.form['dob'],request.form['gender'],request.form['aadhaar_number'],request.form['address'],request.form['state'],request.form['district'],request.form['pincode'],pp,request.form['skill'],request.form.get('experience_years',0)))
            conn.commit(); flash('Registered! Complete KYC now.','success'); return redirect(url_for('kyc_verify'))
        except sqlite3.IntegrityError: flash('Aadhaar already registered.','danger')
        finally: conn.close()
    return render_template('worker_register.html')

@app.route('/otp/send', methods=['POST'])
@login_required
def otp_send():
    conn=get_db(); user=conn.execute("SELECT * FROM users WHERE id=?",(session['user_id'],)).fetchone()
    if not user or not user['email']:
        conn.close(); return jsonify({'success':False,'message':'No email registered on your account.'})
    email=user['email']; purpose=request.form.get('purpose','KYC Verification')
    conn.execute("UPDATE otp_store SET used=1 WHERE user_id=? AND purpose=? AND used=0",(session['user_id'],purpose))
    otp_code=generate_otp(6); expires=datetime.now()+timedelta(minutes=OTP_EXPIRY_MINUTES)
    conn.execute("INSERT INTO otp_store (user_id,email,otp_code,purpose,expires_at) VALUES (?,?,?,?,?)",(session['user_id'],email,otp_code,purpose,expires))
    conn.commit(); conn.close()
    success,msg=send_otp_email(email,otp_code,purpose)
    masked=email[:3]+'****'+email[email.find('@'):]
    if success: return jsonify({'success':True,'message':f'OTP sent to {masked}','email_masked':masked})
    return jsonify({'success':True,'message':f'[DEV MODE] SMTP not configured. OTP: {otp_code}','dev_otp':otp_code,'email_masked':email})

@app.route('/otp/verify', methods=['POST'])
@login_required
def otp_verify_api():
    entered=request.form.get('otp','').strip(); purpose=request.form.get('purpose','KYC Verification')
    conn=get_db(); rec=conn.execute("SELECT * FROM otp_store WHERE user_id=? AND purpose=? AND used=0 ORDER BY created_at DESC LIMIT 1",(session['user_id'],purpose)).fetchone()
    if not rec: conn.close(); return jsonify({'success':False,'message':'No active OTP. Request a new one.'})
    exp=datetime.strptime(str(rec['expires_at'])[:19],'%Y-%m-%d %H:%M:%S')
    if datetime.now()>exp:
        conn.execute("UPDATE otp_store SET used=1 WHERE id=?",(rec['id'],)); conn.commit(); conn.close()
        return jsonify({'success':False,'message':'OTP expired. Request a new one.'})
    if rec['attempts']>=3:
        conn.execute("UPDATE otp_store SET used=1 WHERE id=?",(rec['id'],)); conn.commit(); conn.close()
        return jsonify({'success':False,'message':'Too many wrong attempts. Request a new OTP.'})
    if entered==rec['otp_code']:
        conn.execute("UPDATE otp_store SET used=1 WHERE id=?",(rec['id'],))
        conn.execute("UPDATE users SET email_verified=1 WHERE id=?",(session['user_id'],))
        conn.commit(); conn.close(); session['otp_verified']=True
        return jsonify({'success':True,'message':'OTP verified successfully!'})
    conn.execute("UPDATE otp_store SET attempts=attempts+1 WHERE id=?",(rec['id'],))
    conn.commit(); conn.close()
    return jsonify({'success':False,'message':f'Wrong OTP. {3-rec["attempts"]-1} attempt(s) left.'})

@app.route('/kyc/verify', methods=['GET','POST'])
@login_required
@role_required('worker')
def kyc_verify():
    conn=get_db(); w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
    if not w: conn.close(); flash('Complete registration first.','warning'); return redirect(url_for('worker_register'))
    user=conn.execute("SELECT * FROM users WHERE id=?",(session['user_id'],)).fetchone()
    existing=conn.execute("SELECT * FROM kyc_verifications WHERE worker_id=? ORDER BY id DESC LIMIT 1",(w['id'],)).fetchone(); conn.close()
    if request.method=='POST':
        if not session.get('otp_verified'): flash('Verify your email OTP first.','warning'); return redirect(url_for('kyc_verify'))
        aa=request.form['aadhaar_number']; nm=request.form['name_on_aadhaar']; db=request.form['dob_on_aadhaar']; ad=request.form['address_on_aadhaar']
        ok=len(aa)==12 and aa.isdigit() and (not w['aadhaar_number'] or w['aadhaar_number']==aa) and len(nm.strip())>=3
        tok=str(uuid.uuid4()); conn=get_db()
        if existing:
            conn.execute("UPDATE kyc_verifications SET aadhaar_number=?,name_on_aadhaar=?,dob_on_aadhaar=?,address_on_aadhaar=?,verification_token=?,verified_status=?,verification_date=?,remarks=?,otp_verified=1 WHERE worker_id=?",
                (aa,nm,db,ad,tok,'verified' if ok else 'failed',datetime.now(),'Verified+OTP' if ok else 'Mismatch',w['id']))
        else:
            conn.execute("INSERT INTO kyc_verifications (worker_id,aadhaar_number,name_on_aadhaar,dob_on_aadhaar,address_on_aadhaar,verification_token,verified_status,verification_date,remarks,otp_verified) VALUES (?,?,?,?,?,?,?,?,?,1)",
                (w['id'],aa,nm,db,ad,tok,'verified' if ok else 'failed',datetime.now(),'Verified+OTP' if ok else 'Mismatch'))
        conn.execute("UPDATE workers SET kyc_status=?,kyc_verified_at=? WHERE id=?",('verified' if ok else 'failed',datetime.now() if ok else None,w['id']))
        conn.commit(); conn.close(); session.pop('otp_verified',None)
        flash('KYC Verified via DigiLocker + Email OTP!' if ok else 'KYC failed. Details mismatch.','success' if ok else 'danger')
        return redirect(url_for('kyc_status'))
    return render_template('kyc_verify.html',worker=w,existing_kyc=existing,user=user)

@app.route('/kyc/status')
@login_required
def kyc_status():
    conn=get_db(); w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
    kyc=conn.execute("SELECT * FROM kyc_verifications WHERE worker_id=? ORDER BY id DESC LIMIT 1",(w['id'],)).fetchone() if w else None
    conn.close(); return render_template('kyc_status.html',worker=w,kyc=kyc)

@app.route('/workers')
@login_required
@role_required('admin','contractor')
def workers_list():
    conn=get_db(); s=request.args.get('search',''); kf=request.args.get('kyc','')
    q="SELECT w.*,u.username,u.email FROM workers w JOIN users u ON w.user_id=u.id WHERE 1=1"; p=[]
    if s: q+=" AND (w.full_name LIKE ? OR w.aadhaar_number LIKE ? OR w.skill LIKE ?)"; p.extend([f'%{s}%']*3)
    if kf: q+=" AND w.kyc_status=?"; p.append(kf)
    workers=conn.execute(q+' ORDER BY w.registration_date DESC',p).fetchall(); conn.close()
    return render_template('workers_list.html',workers=workers,search=s,kyc_filter=kf)

@app.route('/worker/<int:worker_id>')
@login_required
def worker_detail(worker_id):
    conn=get_db()
    w=conn.execute("SELECT w.*,u.username,u.email,u.phone FROM workers w JOIN users u ON w.user_id=u.id WHERE w.id=?",(worker_id,)).fetchone()
    if not w: conn.close(); flash('Not found.','danger'); return redirect(url_for('workers_list'))
    kyc=conn.execute("SELECT * FROM kyc_verifications WHERE worker_id=? ORDER BY id DESC LIMIT 1",(worker_id,)).fetchone()
    asn=conn.execute("SELECT a.*,s.site_name,s.location FROM assignments a JOIN sites s ON a.site_id=s.id WHERE a.worker_id=? ORDER BY a.assigned_date DESC",(worker_id,)).fetchall()
    att=conn.execute("SELECT * FROM attendance WHERE worker_id=? ORDER BY attendance_date DESC LIMIT 10",(worker_id,)).fetchall()
    wg=conn.execute("SELECT * FROM wages WHERE worker_id=? ORDER BY created_at DESC LIMIT 10",(worker_id,)).fetchall()
    cmp=conn.execute("SELECT * FROM complaints WHERE worker_id=? ORDER BY submitted_at DESC",(worker_id,)).fetchall()
    conn.close(); return render_template('worker_detail.html',worker=w,kyc=kyc,assignments=asn,attendance=att,wages=wg,complaints=cmp)

@app.route('/kyc/approve/<int:worker_id>', methods=['POST'])
@login_required
@role_required('admin')
def kyc_approve(worker_id):
    conn=get_db(); act=request.form.get('action')
    if act=='approve':
        conn.execute("UPDATE workers SET kyc_status='verified',kyc_verified_at=? WHERE id=?",(datetime.now(),worker_id))
        conn.execute("UPDATE kyc_verifications SET verified_status='verified' WHERE worker_id=?",(worker_id,)); flash('KYC approved.','success')
    else:
        conn.execute("UPDATE workers SET kyc_status='rejected' WHERE id=?",(worker_id,))
        conn.execute("UPDATE kyc_verifications SET verified_status='rejected',remarks=? WHERE worker_id=?",(request.form.get('remarks','Rejected'),worker_id)); flash('Rejected.','warning')
    conn.commit(); conn.close(); return redirect(url_for('worker_detail',worker_id=worker_id))

@app.route('/sites')
@login_required
def sites_list():
    conn=get_db()
    if session['role']=='contractor':
        con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
        sites=conn.execute("SELECT s.*,c.company_name,(SELECT COUNT(*) FROM assignments a WHERE a.site_id=s.id AND a.status='active') as worker_count FROM sites s JOIN contractors c ON s.contractor_id=c.id WHERE s.contractor_id=? ORDER BY s.created_at DESC",(con['id'],)).fetchall() if con else []
    else:
        sites=conn.execute("SELECT s.*,c.company_name,(SELECT COUNT(*) FROM assignments a WHERE a.site_id=s.id AND a.status='active') as worker_count FROM sites s JOIN contractors c ON s.contractor_id=c.id ORDER BY s.created_at DESC").fetchall()
    conn.close(); return render_template('sites_list.html',sites=sites)

@app.route('/sites/add', methods=['GET','POST'])
@login_required
@role_required('contractor','admin')
def site_add():
    conn=get_db(); con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
    if request.method=='POST':
        cid=request.form.get('contractor_id') or (con['id'] if con else None)
        conn.execute("INSERT INTO sites (contractor_id,site_name,location,state,district,project_type,start_date,end_date,total_workers_needed) VALUES (?,?,?,?,?,?,?,?,?)",
            (cid,request.form['site_name'],request.form['location'],request.form['state'],request.form['district'],request.form['project_type'],request.form['start_date'],request.form.get('end_date',''),request.form.get('total_workers_needed',0)))
        conn.commit(); conn.close(); flash('Site added!','success'); return redirect(url_for('sites_list'))
    cons=conn.execute("SELECT * FROM contractors").fetchall(); conn.close()
    return render_template('site_add.html',contractor=con,contractors=cons)

@app.route('/sites/<int:site_id>')
@login_required
def site_detail(site_id):
    conn=get_db()
    site=conn.execute("SELECT s.*,c.company_name,c.contact_person FROM sites s JOIN contractors c ON s.contractor_id=c.id WHERE s.id=?",(site_id,)).fetchone()
    asn=conn.execute("SELECT a.*,w.full_name,w.skill,w.photo_path,w.kyc_status FROM assignments a JOIN workers w ON a.worker_id=w.id WHERE a.site_id=? ORDER BY a.assigned_date DESC",(site_id,)).fetchall()
    conn.close(); return render_template('site_detail.html',site=site,assignments=asn)

@app.route('/assignments/add', methods=['GET','POST'])
@login_required
@role_required('contractor','admin')
def assignment_add():
    conn=get_db(); con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
    if request.method=='POST':
        cid=con['id'] if con else request.form.get('contractor_id')
        conn.execute("INSERT INTO assignments (worker_id,site_id,contractor_id,assigned_date,end_date,designation,daily_wage) VALUES (?,?,?,?,?,?,?)",
            (request.form['worker_id'],request.form['site_id'],cid,request.form['assigned_date'],request.form.get('end_date',''),request.form['designation'],request.form.get('daily_wage',0)))
        conn.commit(); conn.close(); flash('Assigned!','success'); return redirect(url_for('sites_list'))
    sites=conn.execute("SELECT * FROM sites WHERE contractor_id=? AND status='active'",(con['id'],)).fetchall() if con else conn.execute("SELECT * FROM sites WHERE status='active'").fetchall()
    workers=conn.execute("SELECT * FROM workers WHERE kyc_status='verified' AND status='active'").fetchall(); conn.close()
    return render_template('assignment_add.html',sites=sites,workers=workers,contractor=con)

@app.route('/attendance', methods=['GET','POST'])
@login_required
def attendance():
    conn=get_db(); role=session['role']
    if request.method=='POST' and role in ('contractor','admin'):
        sid=request.form['site_id']; dt=request.form['attendance_date']
        for wid,st in zip(request.form.getlist('worker_ids'),request.form.getlist('statuses')):
            if not conn.execute("SELECT id FROM attendance WHERE worker_id=? AND site_id=? AND attendance_date=?",(wid,sid,dt)).fetchone():
                conn.execute("INSERT INTO attendance (worker_id,site_id,attendance_date,status,marked_by) VALUES (?,?,?,?,?)",(wid,sid,dt,st,session['user_id']))
        conn.commit(); flash('Attendance saved!','success')
    if role=='worker':
        w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
        rec=conn.execute("SELECT a.*,s.site_name FROM attendance a JOIN sites s ON a.site_id=s.id WHERE a.worker_id=? ORDER BY a.attendance_date DESC LIMIT 30",(w['id'],)).fetchall() if w else []
        conn.close(); return render_template('attendance_worker.html',records=rec,worker=w)
    elif role=='contractor':
        con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
        sites=conn.execute("SELECT * FROM sites WHERE contractor_id=? AND status='active'",(con['id'],)).fetchall()
        ss=request.args.get('site_id'); ws=[]
        if ss: ws=conn.execute("SELECT w.*,a.id as assignment_id FROM workers w JOIN assignments a ON w.id=a.worker_id WHERE a.site_id=? AND a.status='active'",(ss,)).fetchall()
        conn.close(); return render_template('attendance_contractor.html',sites=sites,workers_on_site=ws,selected_site=ss)
    else:
        rec=conn.execute("SELECT a.*,w.full_name,s.site_name FROM attendance a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id ORDER BY a.attendance_date DESC LIMIT 50").fetchall()
        conn.close(); return render_template('attendance_admin.html',records=rec)

@app.route('/wages', methods=['GET','POST'])
@login_required
def wages():
    conn=get_db(); role=session['role']
    if request.method=='POST' and role in ('contractor','admin'):
        wid=request.form['worker_id']; sid=request.form['site_id']; prd=request.form['payment_period']
        d=int(request.form.get('days_worked',0)); dw=float(request.form.get('daily_wage',0)); ded=float(request.form.get('deductions',0))
        tot=d*dw; net=tot-ded
        conn.execute("INSERT INTO wages (worker_id,site_id,payment_period,days_worked,daily_wage,total_amount,deductions,net_amount,payment_date,payment_status,payment_mode,transaction_id,paid_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (wid,sid,prd,d,dw,tot,ded,net,request.form.get('payment_date',str(date.today())),request.form.get('payment_status','pending'),request.form.get('payment_mode',''),request.form.get('transaction_id',''),session['user_id']))
        conn.commit(); flash('Wage record added!','success')
    if role=='worker':
        w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
        rec=conn.execute("SELECT wg.*,s.site_name FROM wages wg JOIN sites s ON wg.site_id=s.id WHERE wg.worker_id=? ORDER BY wg.created_at DESC",(w['id'],)).fetchall() if w else []
        conn.close(); return render_template('wages_worker.html',records=rec,worker=w)
    elif role=='contractor':
        con=conn.execute("SELECT * FROM contractors WHERE user_id=?",(session['user_id'],)).fetchone()
        sites=conn.execute("SELECT * FROM sites WHERE contractor_id=? ORDER BY site_name",(con['id'],)).fetchall()
        # Show ALL verified workers assigned to contractor's sites (with assignment details for auto-fill)
        workers=conn.execute("""SELECT DISTINCT w.id,w.full_name,w.skill,w.experience_years,
            a.daily_wage as assigned_wage, a.site_id as assigned_site_id, a.designation,
            s.site_name as assigned_site_name
            FROM workers w
            JOIN assignments a ON w.id=a.worker_id
            JOIN sites s ON a.site_id=s.id
            WHERE a.contractor_id=? AND a.status='active' AND w.status='active'
            ORDER BY w.full_name""",(con['id'],)).fetchall()
        # If no assignments yet, fall back to all verified workers
        if not workers:
            workers=conn.execute("SELECT id,full_name,skill,experience_years,0 as assigned_wage,0 as assigned_site_id,'' as designation,'' as assigned_site_name FROM workers WHERE kyc_status='verified' AND status='active' ORDER BY full_name").fetchall()
        rec=conn.execute("""SELECT wg.*,w.full_name,s.site_name
            FROM wages wg
            JOIN workers w ON wg.worker_id=w.id
            JOIN sites s ON wg.site_id=s.id
            WHERE wg.site_id IN (SELECT id FROM sites WHERE contractor_id=?)
            GROUP BY wg.id ORDER BY wg.created_at DESC""",(con['id'],)).fetchall()
        conn.close(); return render_template('wages_contractor.html',records=rec,sites=sites,workers=workers)
    else:
        rec=conn.execute("SELECT wg.*,w.full_name,s.site_name FROM wages wg JOIN workers w ON wg.worker_id=w.id JOIN sites s ON wg.site_id=s.id ORDER BY wg.created_at DESC").fetchall()
        tp=conn.execute("SELECT COALESCE(SUM(net_amount),0) FROM wages WHERE payment_status='paid'").fetchone()[0]
        tpend=conn.execute("SELECT COALESCE(SUM(net_amount),0) FROM wages WHERE payment_status='pending'").fetchone()[0]
        conn.close(); return render_template('wages_admin.html',records=rec,total_paid=tp,total_pending=tpend)

@app.route('/complaints', methods=['GET','POST'])
@login_required
def complaints():
    conn=get_db(); role=session['role']
    if request.method=='POST' and role=='worker':
        w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
        if w:
            conn.execute("INSERT INTO complaints (worker_id,site_id,category,subject,description,priority) VALUES (?,?,?,?,?,?)",
                (w['id'],request.form.get('site_id') or None,request.form['category'],request.form['subject'],request.form['description'],request.form.get('priority','medium')))
            conn.commit(); flash('Complaint submitted!','success')
    if role=='worker':
        w=conn.execute("SELECT * FROM workers WHERE user_id=?",(session['user_id'],)).fetchone()
        rec=conn.execute("SELECT c.*,s.site_name FROM complaints c LEFT JOIN sites s ON c.site_id=s.id WHERE c.worker_id=? ORDER BY c.submitted_at DESC",(w['id'],)).fetchall() if w else []
        asn=conn.execute("SELECT a.*,s.site_name FROM assignments a JOIN sites s ON a.site_id=s.id WHERE a.worker_id=?",(w['id'],)).fetchall() if w else []
        conn.close(); return render_template('complaints_worker.html',records=rec,worker=w,assignments=asn)
    rec=conn.execute("SELECT c.*,w.full_name,s.site_name FROM complaints c JOIN workers w ON c.worker_id=w.id LEFT JOIN sites s ON c.site_id=s.id ORDER BY c.submitted_at DESC").fetchall()
    conn.close(); return render_template('complaints_admin.html',records=rec)

@app.route('/complaints/resolve/<int:cid>', methods=['POST'])
@login_required
@role_required('admin')
def resolve_complaint(cid):
    conn=get_db()
    conn.execute("UPDATE complaints SET status='resolved',resolved_at=?,resolved_by=?,resolution_notes=? WHERE id=?",(datetime.now(),session['user_id'],request.form.get('resolution_notes',''),cid))
    conn.commit(); conn.close(); flash('Resolved.','success'); return redirect(url_for('complaints'))

@app.route('/analytics')
@login_required
@role_required('admin')
def analytics():
    conn=get_db()
    d={'total_workers':conn.execute("SELECT COUNT(*) FROM workers").fetchone()[0],
       'verified_workers':conn.execute("SELECT COUNT(*) FROM workers WHERE kyc_status='verified'").fetchone()[0],
       'pending_kyc':conn.execute("SELECT COUNT(*) FROM workers WHERE kyc_status='pending'").fetchone()[0],
       'total_sites':conn.execute("SELECT COUNT(*) FROM sites").fetchone()[0],
       'active_sites':conn.execute("SELECT COUNT(*) FROM sites WHERE status='active'").fetchone()[0],
       'total_wages':conn.execute("SELECT COALESCE(SUM(net_amount),0) FROM wages WHERE payment_status='paid'").fetchone()[0],
       'open_complaints':conn.execute("SELECT COUNT(*) FROM complaints WHERE status='open'").fetchone()[0],
       'skill_dist':rows_to_dicts(conn.execute("SELECT skill, COUNT(*) as count FROM workers GROUP BY skill ORDER BY count DESC").fetchall()),
       'state_dist':rows_to_dicts(conn.execute("SELECT state, COUNT(*) as count FROM workers GROUP BY state ORDER BY count DESC LIMIT 10").fetchall()),
       'monthly_reg':rows_to_dicts(conn.execute("SELECT strftime('%Y-%m', registration_date) as month, COUNT(*) as count FROM workers GROUP BY month ORDER BY month DESC LIMIT 6").fetchall()),
       'wage_monthly':rows_to_dicts(conn.execute("SELECT strftime('%Y-%m', payment_date) as month, SUM(net_amount) as total FROM wages WHERE payment_status='paid' GROUP BY month ORDER BY month DESC LIMIT 6").fetchall())}
    conn.close(); return render_template('analytics.html',**d)

# ══════════════════════════════════════════════════════════════
#  ALL 6 ANALYTICAL REPORTS
# ══════════════════════════════════════════════════════════════

@app.route('/reports/state-workers')
@login_required
@role_required('admin')
def report_state_workers():
    conn=get_db()
    state_counts=rows_to_dicts(conn.execute("SELECT state,COUNT(*) as total,SUM(CASE WHEN kyc_status='verified' THEN 1 ELSE 0 END) as verified,SUM(CASE WHEN kyc_status='pending' THEN 1 ELSE 0 END) as pending FROM workers WHERE state IS NOT NULL AND state!='' GROUP BY state ORDER BY total DESC").fetchall())
    top_skill={}
    for r in state_counts:
        sk=conn.execute("SELECT skill,COUNT(*) as cnt FROM workers WHERE state=? AND skill IS NOT NULL GROUP BY skill ORDER BY cnt DESC LIMIT 1",(r['state'],)).fetchone()
        top_skill[r['state']]=sk['skill'] if sk else '—'
    breakdown=rows_to_dicts(conn.execute("SELECT state,skill,COUNT(*) as cnt FROM workers WHERE state IS NOT NULL AND state!='' AND skill IS NOT NULL GROUP BY state,skill ORDER BY state,cnt DESC").fetchall())
    conn.close()
    return render_template('report_state_workers.html',state_counts=state_counts,top_skill_per_state=top_skill,state_skill_breakdown=breakdown,top_states=state_counts[:3])

@app.route('/reports/monthly-registrations')
@login_required
@role_required('admin')
def report_monthly_registrations():
    conn=get_db()
    mw=rows_to_dicts(conn.execute("SELECT strftime('%Y-%m',registration_date) as month,COUNT(*) as total,SUM(CASE WHEN gender='Male' THEN 1 ELSE 0 END) as male,SUM(CASE WHEN gender='Female' THEN 1 ELSE 0 END) as female,SUM(CASE WHEN kyc_status='verified' THEN 1 ELSE 0 END) as verified FROM workers GROUP BY month ORDER BY month DESC LIMIT 12").fetchall())
    yearly=rows_to_dicts(conn.execute("SELECT strftime('%Y',registration_date) as year,COUNT(*) as total FROM workers GROUP BY year ORDER BY year DESC LIMIT 5").fetchall())
    sm=rows_to_dicts(conn.execute("SELECT strftime('%Y-%m',registration_date) as month,skill,COUNT(*) as cnt FROM workers WHERE skill IS NOT NULL GROUP BY month,skill ORDER BY month DESC,cnt DESC").fetchall())
    all_m=list(reversed(mw)); run=0; rt=[]
    for m in all_m: run+=m['total']; rt.append(run)
    conn.close(); return render_template('report_monthly_registrations.html',monthly_workers=mw,yearly=yearly,skill_monthly=sm,all_months=all_m,running_totals=rt)

@app.route('/reports/monthly-contractors')
@login_required
@role_required('admin')
def report_monthly_contractors():
    conn=get_db()
    mc=rows_to_dicts(conn.execute("SELECT strftime('%Y-%m',registration_date) as month,COUNT(*) as total,COUNT(DISTINCT state) as states_covered FROM contractors GROUP BY month ORDER BY month DESC LIMIT 12").fetchall())
    cs=rows_to_dicts(conn.execute("SELECT state,COUNT(*) as cnt FROM contractors WHERE state IS NOT NULL AND state!='' GROUP BY state ORDER BY cnt DESC").fetchall())
    cst=rows_to_dicts(conn.execute("SELECT c.company_name,c.state,COUNT(s.id) as site_count,SUM(s.total_workers_needed) as workers_needed FROM contractors c LEFT JOIN sites s ON s.contractor_id=c.id GROUP BY c.id ORDER BY site_count DESC LIMIT 10").fetchall())
    tc=conn.execute("SELECT COUNT(*) FROM contractors").fetchone()[0]; ac=conn.execute("SELECT COUNT(*) FROM contractors WHERE status='active'").fetchone()[0]
    conn.close(); return render_template('report_monthly_contractors.html',monthly_contractors=mc,contractor_states=cs,contractor_sites=cst,total_contractors=tc,active_contractors=ac)

@app.route('/reports/worker-demand')
@login_required
@role_required('admin')
def report_worker_demand():
    conn=get_db()
    supply=dict(conn.execute("SELECT state,COUNT(*) FROM workers WHERE state IS NOT NULL AND state!='' GROUP BY state").fetchall())
    demand_rows=rows_to_dicts(conn.execute("SELECT state,SUM(total_workers_needed) as demand,COUNT(id) as site_count,SUM(CASE WHEN status='active' THEN total_workers_needed ELSE 0 END) as active_demand FROM sites WHERE state IS NOT NULL AND state!='' GROUP BY state ORDER BY demand DESC").fetchall())
    assigned=dict(conn.execute("SELECT s.state,COUNT(DISTINCT a.worker_id) as assigned FROM assignments a JOIN sites s ON a.site_id=s.id WHERE a.status='active' AND s.state IS NOT NULL GROUP BY s.state").fetchall())
    da=[]
    for r in demand_rows:
        st=r['state']; dem=r['demand'] or 0; sup=supply.get(st,0); ass=assigned.get(st,0); gap=dem-ass
        pct=round(ass/dem*100,1) if dem>0 else 0
        da.append({'state':st,'demand':dem,'supply':sup,'assigned':ass,'gap':gap,'site_count':r['site_count'],'pct_fill':pct,'status':'critical' if pct<30 else ('low' if pct<70 else 'good')})
    sd=rows_to_dicts(conn.execute("SELECT designation as skill,COUNT(*) as cnt FROM assignments WHERE status='active' GROUP BY designation ORDER BY cnt DESC LIMIT 8").fetchall())
    hd=sorted([d for d in da if d['gap']>0],key=lambda x:x['gap'],reverse=True)[:5]
    conn.close(); return render_template('report_worker_demand.html',demand_analysis=da,skill_demand=sd,high_demand=hd)

@app.route('/reports/migration-patterns')
@login_required
@role_required('admin')
def report_migration_patterns():
    conn=get_db()
    mf=rows_to_dicts(conn.execute("SELECT w.state as origin_state,s.state as dest_state,COUNT(*) as workers FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state IS NOT NULL AND s.state IS NOT NULL AND w.state!='' AND s.state!='' GROUP BY w.state,s.state ORDER BY workers DESC LIMIT 20").fetchall())
    mc=conn.execute("SELECT COUNT(DISTINCT a.worker_id) FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state!=s.state AND w.state IS NOT NULL AND s.state IS NOT NULL").fetchone()[0]
    ta=conn.execute("SELECT COUNT(DISTINCT worker_id) FROM assignments WHERE status='active'").fetchone()[0]
    ts=rows_to_dicts(conn.execute("SELECT w.state,COUNT(DISTINCT a.worker_id) as migrants FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state!=s.state AND w.state IS NOT NULL GROUP BY w.state ORDER BY migrants DESC LIMIT 8").fetchall())
    td=rows_to_dicts(conn.execute("SELECT s.state,COUNT(DISTINCT a.worker_id) as migrants FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state!=s.state AND s.state IS NOT NULL GROUP BY s.state ORDER BY migrants DESC LIMIT 8").fetchall())
    skm=rows_to_dicts(conn.execute("SELECT w.skill,COUNT(DISTINCT a.worker_id) as migrated_workers,COUNT(DISTINCT s.state) as dest_states FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state!=s.state AND w.skill IS NOT NULL GROUP BY w.skill ORDER BY migrated_workers DESC LIMIT 8").fetchall())
    mt=rows_to_dicts(conn.execute("SELECT strftime('%Y-%m',a.assigned_date) as month,COUNT(DISTINCT a.worker_id) as count FROM assignments a JOIN workers w ON a.worker_id=w.id JOIN sites s ON a.site_id=s.id WHERE w.state!=s.state GROUP BY month ORDER BY month DESC LIMIT 8").fetchall())
    conn.close()
    return render_template('report_migration_patterns.html',migration_flows=mf,migrated_count=mc,total_assigned=ta,top_sources=ts,top_destinations=td,skill_migration=skm,migration_trend=mt)

@app.route('/reports/wage-disbursal')
@login_required
@role_required('admin')
def report_wage_disbursal():
    conn=get_db()
    mw=rows_to_dicts(conn.execute("SELECT strftime('%Y-%m',payment_date) as month,COUNT(*) as records,COUNT(DISTINCT worker_id) as workers_paid,SUM(days_worked) as total_days,SUM(total_amount) as gross,SUM(deductions) as deductions,SUM(net_amount) as net,SUM(CASE WHEN payment_status='paid' THEN net_amount ELSE 0 END) as paid,SUM(CASE WHEN payment_status='pending' THEN net_amount ELSE 0 END) as pending FROM wages WHERE payment_date IS NOT NULL AND payment_date!='' GROUP BY month ORDER BY month DESC LIMIT 12").fetchall())
    pm=rows_to_dicts(conn.execute("SELECT payment_mode,COUNT(*) as cnt,SUM(net_amount) as total FROM wages WHERE payment_mode IS NOT NULL AND payment_mode!='' GROUP BY payment_mode ORDER BY total DESC").fetchall())
    sw=rows_to_dicts(conn.execute("SELECT w.state,SUM(wg.net_amount) as total_wages,COUNT(DISTINCT wg.worker_id) as workers,AVG(wg.daily_wage) as avg_daily_wage FROM wages wg JOIN workers w ON wg.worker_id=w.id WHERE w.state IS NOT NULL AND w.state!='' GROUP BY w.state ORDER BY total_wages DESC LIMIT 10").fetchall())
    skw=rows_to_dicts(conn.execute("SELECT w.skill,AVG(wg.daily_wage) as avg_wage,SUM(wg.net_amount) as total_paid,COUNT(DISTINCT wg.worker_id) as workers FROM wages wg JOIN workers w ON wg.worker_id=w.id WHERE w.skill IS NOT NULL GROUP BY w.skill ORDER BY avg_wage DESC").fetchall())
    kpis=row_to_dict(conn.execute("SELECT COUNT(*) as total_records,COUNT(DISTINCT worker_id) as total_workers,SUM(net_amount) as total_net,SUM(CASE WHEN payment_status='paid' THEN net_amount ELSE 0 END) as total_paid,SUM(CASE WHEN payment_status='pending' THEN net_amount ELSE 0 END) as total_pending,AVG(daily_wage) as avg_daily_wage,MAX(net_amount) as highest_payment FROM wages").fetchone()) or {}
    pl=rows_to_dicts(conn.execute("SELECT wg.*,w.full_name,w.state,s.site_name FROM wages wg JOIN workers w ON wg.worker_id=w.id JOIN sites s ON wg.site_id=s.id WHERE wg.payment_status='pending' ORDER BY wg.created_at DESC LIMIT 15").fetchall())
    conn.close()
    return render_template('report_wage_disbursal.html',monthly_wages=mw,payment_modes=pm,state_wages=sw,skill_wages=skw,kpis=kpis,pending_list=pl)

@app.route('/api/stats')
@login_required
@role_required('admin')
def api_stats():
    conn=get_db()
    r={'skills':dict(conn.execute("SELECT skill,COUNT(*) FROM workers GROUP BY skill").fetchall()),'states':dict(conn.execute("SELECT state,COUNT(*) FROM workers GROUP BY state").fetchall())}
    conn.close(); return jsonify(r)

if __name__=='__main__':
    init_db(); app.run(debug=True,port=5000)
