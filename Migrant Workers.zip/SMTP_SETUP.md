# MigrantWorks — SMTP Email OTP Configuration Guide
# =====================================================

## Setup Steps (Gmail SMTP)

1. Enable 2-Factor Authentication on your Gmail account.
2. Go to: Google Account → Security → App Passwords
3. Create an App Password for "Mail" → "Windows Computer" (or any device)
4. Copy the 16-character app password.

## Update app.py (top of file)

```python
SMTP_HOST     = 'smtp.gmail.com'
SMTP_PORT     = 587
SMTP_USER     = 'youremail@gmail.com'        # Your Gmail address
SMTP_PASSWORD = 'xxxx xxxx xxxx xxxx'        # 16-char App Password (no spaces)
SMTP_FROM     = 'MigrantWorks <youremail@gmail.com>'
OTP_EXPIRY_MINUTES = 10
```

## Alternative SMTP Providers

### Outlook / Hotmail
```python
SMTP_HOST = 'smtp-mail.outlook.com'
SMTP_PORT = 587
```

### Yahoo Mail
```python
SMTP_HOST = 'smtp.mail.yahoo.com'
SMTP_PORT = 587
```

### Custom / Company SMTP
```python
SMTP_HOST = 'mail.yourcompany.com'
SMTP_PORT = 587   # or 465 for SSL
```

## For SSL (port 465), change send_otp_email() to:
```python
with smtplib.SMTP_SSL(SMTP_HOST, 465) as server:
    server.login(SMTP_USER, SMTP_PASSWORD)
    server.sendmail(...)
```

## Dev/Offline Mode
If SMTP is not configured, the system runs in DEV MODE:
- OTP is shown in a browser alert popup
- This is for development/testing only
- The OTP still gets saved to the otp_store table and works normally

## Database Tables Added
- otp_store: Stores OTP codes with expiry, attempt tracking
  - Fields: user_id, email, otp_code, purpose, expires_at, used, attempts
- users.email_verified: Tracks if email has been OTP-verified
- kyc_verifications.otp_verified: Records if KYC used OTP
