# MigrantWorks v2 — Centralized Migrant Construction Workforce Management

## Quick Start

```bash
pip install flask werkzeug
python app.py
# Open: http://localhost:5000
```

## Demo Accounts
| Role       | Username      | Password  |
|------------|---------------|-----------|
| Admin      | `admin`       | `admin123`|
| Contractor | `contractor1` | `pass123` |
| Worker     | `worker1`     | `pass123` |

---

## What's New in v2

### 6 Analytics Reports (Admin only)
| URL | Report |
|-----|--------|
| `/reports/state-workers` | State-wise worker count + highest supplying state per skill |
| `/reports/monthly-registrations` | Monthly worker registrations with gender split & cumulative trend |
| `/reports/monthly-contractors` | Monthly contractor registrations + company site count |
| `/reports/worker-demand` | State-wise demand vs supply gap — critical states highlighted |
| `/reports/migration-patterns` | Origin→Destination migration flows, skill-wise migration |
| `/reports/wage-disbursal` | Monthly wage disbursals, payment modes, state & skill averages |

### Email OTP for KYC Verification
- Worker clicks **Send OTP** → 6-digit OTP sent via SMTP to registered email
- OTP is valid for 10 minutes, max 3 attempts
- KYC Aadhaar form is **locked** until OTP is verified
- DEV MODE: if SMTP not configured, OTP shown in browser popup for testing

### New Database Tables
- `otp_store` — OTP codes with expiry timestamps and attempt counter
- `users.email_verified` — tracks email OTP verification status
- `kyc_verifications.otp_verified` — records that OTP was used for this KYC

---

## SMTP Email Configuration

Edit these lines at the top of `app.py`:

```python
SMTP_HOST     = 'smtp.gmail.com'       # your SMTP server
SMTP_PORT     = 587
SMTP_USER     = 'youremail@gmail.com'  # your email
SMTP_PASSWORD = 'your-app-password'    # Gmail App Password (16 chars)
SMTP_FROM     = 'MigrantWorks <youremail@gmail.com>'
OTP_EXPIRY_MINUTES = 10
```

### Gmail App Password Setup
1. Enable 2FA on your Google account
2. Go to: Google Account → Security → App Passwords
3. Create App Password for Mail → copy 16-character code
4. Paste into `SMTP_PASSWORD` (remove spaces)

See `SMTP_SETUP.md` for other SMTP providers (Outlook, Yahoo, custom).

---

## All Modules
1. Authentication & Role Management (Admin / Contractor / Worker)
2. Worker Registration + Photo Upload
3. KYC Verification: Aadhaar + Email OTP + DigiLocker (sandbox)
4. Contractor & Construction Site Management
5. Worker Assignment & Employment Tracking
6. Digital Attendance Management
7. Wage Payment Records
8. Complaint Submission & Resolution
9. Analytics Overview Dashboard
10. 6 Detailed Report Pages (new in v2)

## File Structure
```
MigrantWorks_v2/
├── app.py                        # Main Flask app (all routes, OTP logic)
├── requirements.txt
├── SMTP_SETUP.md                 # Email OTP configuration guide
├── static/
│   ├── css/
│   │   ├── main.css              # Full design system & CSS variables
│   │   ├── dashboard.css         # Dashboard, charts, modals
│   │   └── auth.css              # Login/register pages
│   ├── js/
│   │   ├── app.js                # Core JS (sidebar, photo upload, counters)
│   │   ├── charts.js             # Chart.js helper builders
│   │   └── kyc.js                # KYC OTP flow JS
│   ├── img/
│   │   ├── logo.svg
│   │   └── favicon.svg
│   └── uploads/                  # Worker photos saved here (auto-created)
└── templates/
    ├── base.html                 # Sidebar layout with report nav links
    ├── login.html / register.html
    ├── *_dashboard.html          # Admin, Contractor, Worker dashboards
    ├── kyc_verify.html           # OTP + Aadhaar KYC form (updated)
    ├── kyc_status.html
    ├── workers_list.html / worker_detail.html / worker_register.html
    ├── sites_list.html / site_add.html / site_detail.html
    ├── assignment_add.html
    ├── attendance_*.html (3 files)
    ├── wages_*.html (3 files)
    ├── complaints_*.html (2 files)
    ├── analytics.html
    ├── report_state_workers.html         ← NEW
    ├── report_monthly_registrations.html ← NEW
    ├── report_monthly_contractors.html   ← NEW
    ├── report_worker_demand.html         ← NEW
    ├── report_migration_patterns.html    ← NEW
    └── report_wage_disbursal.html        ← NEW
```
