/**
 * MigrantWorks — kyc.js
 * KYC / Aadhaar verification page logic
 */

'use strict';

/* ── Step indicator logic ── */
function setStep(step) {
  document.querySelectorAll('.kyc-step').forEach((el, i) => {
    el.classList.remove('active', 'done');
    if (i < step)  el.classList.add('done');
    if (i === step) el.classList.add('active');
  });
}

/* ── Aadhaar format display: groups of 4 ── */
function formatAadhaarDisplay(value) {
  const digits = value.replace(/\D/g, '').slice(0, 12);
  return digits.replace(/(.{4})/g, '$1 ').trim();
}

/* ── OTP simulation UI ── */
let otpRequested = false;

function requestOTP() {
  const aadhaarInput = document.querySelector('input[name="aadhaar_number"]');
  if (!aadhaarInput) return;

  const val = aadhaarInput.value.replace(/\D/g, '');
  if (val.length !== 12) {
    window.showToast && showToast('Enter a valid 12-digit Aadhaar number first', 'warning');
    return;
  }

  const btn = document.getElementById('otpBtn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending OTP...';
  }

  // Simulate API call
  setTimeout(() => {
    otpRequested = true;
    const otpGroup = document.getElementById('otpGroup');
    if (otpGroup) otpGroup.style.display = 'block';
    if (btn) {
      btn.innerHTML = '<i class="fas fa-check me-2"></i>OTP Sent';
      btn.style.background = '#DCFCE7';
      btn.style.color = '#16a34a';
      btn.style.borderColor = '#BBF7D0';
    }
    showToast('OTP sent to mobile linked with Aadhaar (Mock)', 'success');
    setStep(1);

    // Start countdown
    startOTPCountdown(60);
  }, 1500);
}

function startOTPCountdown(seconds) {
  const timerEl = document.getElementById('otpTimer');
  if (!timerEl) return;

  let remaining = seconds;
  const interval = setInterval(() => {
    remaining--;
    timerEl.textContent = `Resend OTP in ${remaining}s`;
    if (remaining <= 0) {
      clearInterval(interval);
      timerEl.innerHTML = '<a href="#" onclick="resendOTP(event)" style="color:#FF6B00;font-weight:600">Resend OTP</a>';
    }
  }, 1000);
}

function resendOTP(e) {
  e && e.preventDefault();
  requestOTP();
}

/* ── OTP input auto-focus next ── */
function initOTPBoxes() {
  const boxes = document.querySelectorAll('.otp-box');
  boxes.forEach((box, i) => {
    box.addEventListener('input', () => {
      box.value = box.value.replace(/\D/g, '').slice(0, 1);
      if (box.value && i < boxes.length - 1) {
        boxes[i + 1].focus();
      }
      checkOTPComplete(boxes);
    });
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !box.value && i > 0) {
        boxes[i - 1].focus();
      }
    });
    box.addEventListener('paste', (e) => {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
      boxes.forEach((b, j) => { b.value = text[j] || ''; });
      if (text.length >= boxes.length) boxes[boxes.length - 1].focus();
      checkOTPComplete(boxes);
    });
  });
}

function checkOTPComplete(boxes) {
  const complete = [...boxes].every(b => b.value);
  const verifyBtn = document.getElementById('verifyOTPBtn');
  if (verifyBtn) {
    verifyBtn.disabled = !complete;
    if (complete) {
      verifyBtn.classList.add('btn-loading-ready');
      setStep(2);
    }
  }
}

function getOTPValue() {
  return [...document.querySelectorAll('.otp-box')].map(b => b.value).join('');
}

/* ── DigiLocker verification animation ── */
function startVerificationAnimation() {
  const steps = [
    { text: 'Connecting to DigiLocker...', icon: 'fa-plug', delay: 0 },
    { text: 'Validating Aadhaar number...', icon: 'fa-hashtag', delay: 800 },
    { text: 'Verifying identity with UIDAI...', icon: 'fa-fingerprint', delay: 1600 },
    { text: 'Cross-checking address details...', icon: 'fa-map-marker-alt', delay: 2400 },
    { text: 'Generating verification token...', icon: 'fa-key', delay: 3200 },
  ];

  const container = document.getElementById('verificationSteps');
  if (!container) return;

  container.innerHTML = '';
  container.style.display = 'block';

  steps.forEach(step => {
    setTimeout(() => {
      const item = document.createElement('div');
      item.style.cssText = 'display:flex;align-items:center;gap:10px;padding:8px 0;font-size:.84rem;color:#1E3155;animation:fadeIn .3s ease';
      item.innerHTML = `
        <div style="width:28px;height:28px;border-radius:50%;background:#FFF8F0;border:2px solid #FF6B00;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <i class="fas ${step.icon}" style="color:#FF6B00;font-size:.7rem"></i>
        </div>
        <span>${step.text}</span>
        <i class="fas fa-check" style="margin-left:auto;color:#16a34a;font-size:.75rem"></i>
      `;
      container.appendChild(item);
    }, step.delay);
  });
}

/* ── Consent checkbox logic ── */
function initConsentCheck() {
  const checkbox = document.getElementById('consent');
  const submitBtn = document.getElementById('submitBtn');
  if (!checkbox || !submitBtn) return;

  function toggleBtn() {
    submitBtn.disabled = !checkbox.checked;
    submitBtn.style.opacity = checkbox.checked ? '1' : '0.5';
  }
  checkbox.addEventListener('change', toggleBtn);
  toggleBtn();
}

/* ── Address character counter ── */
function initAddressCounter() {
  const textarea = document.querySelector('textarea[name="address_on_aadhaar"]');
  if (!textarea) return;

  const counter = document.createElement('div');
  counter.style.cssText = 'font-size:.72rem;color:#9CA3AF;text-align:right;margin-top:3px';
  textarea.parentElement.appendChild(counter);

  function update() {
    const len = textarea.value.length;
    counter.textContent = `${len} characters`;
    counter.style.color = len < 20 ? '#dc2626' : '#9CA3AF';
  }
  textarea.addEventListener('input', update);
  update();
}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  initOTPBoxes();
  initConsentCheck();
  initAddressCounter();

  // Attach OTP button
  const otpBtn = document.getElementById('otpBtn');
  if (otpBtn) otpBtn.addEventListener('click', requestOTP);

  // Attach form submit with animation
  const kycForm = document.getElementById('kycForm');
  const submitBtn = document.getElementById('submitBtn');
  if (kycForm && submitBtn) {
    kycForm.addEventListener('submit', (e) => {
      startVerificationAnimation();
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Verifying via DigiLocker...';
      submitBtn.disabled = true;
      // Let the form submit naturally after a brief delay for UX
      e.preventDefault();
      setTimeout(() => kycForm.submit(), 2000);
    });
  }

  // Initialize at step 0
  setStep(0);
});

window.requestOTP = requestOTP;
window.resendOTP  = resendOTP;
window.getOTPValue = getOTPValue;
