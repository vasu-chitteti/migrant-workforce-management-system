/**
 * MigrantWorks — app.js
 * Core application JavaScript
 */

'use strict';

/* ============================================================
   UTILS
   ============================================================ */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function debounce(fn, wait = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
}

function formatINR(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
}

function showToast(message, type = 'info', duration = 3500) {
  const colors = { success: '#16a34a', danger: '#dc2626', warning: '#ca8a04', info: '#2563eb' };
  const icons  = { success: 'fa-check-circle', danger: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };

  const toast = document.createElement('div');
  toast.style.cssText = `
    position:fixed; bottom:24px; right:24px; z-index:9999;
    background:#fff; border-left:4px solid ${colors[type]};
    border-radius:10px; padding:14px 18px; box-shadow:0 8px 30px rgba(0,0,0,.15);
    display:flex; align-items:center; gap:12px;
    font-family:'Noto Sans',sans-serif; font-size:.88rem;
    max-width:360px; animation:slideInRight .3s ease;
  `;
  toast.innerHTML = `
    <i class="fas ${icons[type]}" style="color:${colors[type]};font-size:1.1rem;flex-shrink:0"></i>
    <span style="color:#1a1a2e;flex:1">${message}</span>
    <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:#9CA3AF;font-size:.85rem;flex-shrink:0"><i class="fas fa-times"></i></button>
  `;

  const style = document.createElement('style');
  style.textContent = '@keyframes slideInRight{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}';
  document.head.appendChild(style);

  document.body.appendChild(toast);
  setTimeout(() => { toast.style.animation = 'none'; toast.style.opacity = '0'; toast.style.transition = 'opacity .3s'; setTimeout(() => toast.remove(), 300); }, duration);
}


/* ============================================================
   SIDEBAR — mobile toggle
   ============================================================ */
function initSidebar() {
  const sidebar = $('.sidebar');
  const toggle  = $('.sidebar-toggle');
  const overlay = document.createElement('div');
  overlay.className = 'sidebar-overlay';
  document.body.appendChild(overlay);

  if (!sidebar || !toggle) return;

  toggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
  });
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });
}


/* ============================================================
   FLASH MESSAGE AUTO-DISMISS
   ============================================================ */
function initAlerts() {
  $$('.alert').forEach((alert, i) => {
    // Auto-dismiss after 5s
    setTimeout(() => {
      alert.style.transition = 'opacity .4s, max-height .4s, margin .4s, padding .4s';
      alert.style.opacity = '0';
      alert.style.maxHeight = '0';
      alert.style.marginBottom = '0';
      alert.style.paddingTop = '0';
      alert.style.paddingBottom = '0';
      setTimeout(() => alert.remove(), 400);
    }, 5000 + i * 300);

    // Manual close
    const closeBtn = alert.querySelector('.btn-close, .alert-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        alert.style.transition = 'opacity .3s';
        alert.style.opacity = '0';
        setTimeout(() => alert.remove(), 300);
      });
    }
  });
}


/* ============================================================
   PHOTO UPLOAD PREVIEW
   ============================================================ */
function initPhotoUpload() {
  const uploadArea = $('#uploadArea');
  const photoInput = $('#photoInput');
  const preview    = $('#photoPreview');
  const placeholder = $('#uploadPlaceholder');

  if (!uploadArea || !photoInput) return;

  // Click
  uploadArea.addEventListener('click', () => photoInput.click());

  // Drag & drop
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
  });
  uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('drag-over'));
  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      photoInput.files = e.dataTransfer.files;
      renderPreview(file);
    } else {
      showToast('Please upload an image file (JPG/PNG)', 'warning');
    }
  });

  // Change
  photoInput.addEventListener('change', () => {
    const file = photoInput.files[0];
    if (file) {
      if (file.size > 3 * 1024 * 1024) {
        showToast('Photo must be less than 3 MB', 'warning');
        return;
      }
      renderPreview(file);
    }
  });

  function renderPreview(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (preview) {
        preview.src = e.target.result;
        preview.style.display = 'block';
      }
      if (placeholder) placeholder.style.display = 'none';
      uploadArea.style.padding = '16px';
    };
    reader.readAsDataURL(file);
  }
}


/* ============================================================
   AADHAAR NUMBER FORMATTING
   ============================================================ */
function initAadhaarInput() {
  $$('input[name="aadhaar_number"]').forEach(input => {
    input.addEventListener('input', () => {
      // Only digits
      let val = input.value.replace(/\D/g, '');
      if (val.length > 12) val = val.slice(0, 12);
      input.value = val;

      // Visual feedback
      const isValid = val.length === 12;
      input.style.borderColor = val.length > 0 ? (isValid ? 'var(--success)' : 'var(--border)') : '';
      input.style.boxShadow   = isValid ? '0 0 0 3px rgba(22,163,74,.12)' : '';
    });
  });
}


/* ============================================================
   KYC FORM — loading simulation
   ============================================================ */
function initKYCForm() {
  const form = $('#kycForm');
  const btn  = $('#submitBtn');
  if (!form || !btn) return;

  form.addEventListener('submit', (e) => {
    const aadhaar = form.querySelector('input[name="aadhaar_number"]')?.value || '';
    const name    = form.querySelector('input[name="name_on_aadhaar"]')?.value || '';

    // Client-side validation
    if (aadhaar.length !== 12 || !/^\d+$/.test(aadhaar)) {
      e.preventDefault();
      showToast('Please enter a valid 12-digit Aadhaar number', 'danger');
      return;
    }
    if (name.trim().length < 3) {
      e.preventDefault();
      showToast('Please enter your full name as on Aadhaar', 'danger');
      return;
    }

    // Show loading
    btn.classList.add('btn-loading');
    btn.disabled = true;
    btn.dataset.origText = btn.innerHTML;
  });
}


/* ============================================================
   ROLE CARD SELECTOR
   ============================================================ */
function selectRole(role, el) {
  $$('.role-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  const input = document.getElementById('role_input');
  if (input) input.value = role;

  const companyGroup = document.getElementById('company_group');
  if (companyGroup) {
    companyGroup.style.display = role === 'contractor' ? 'block' : 'none';
    const companyInput = companyGroup.querySelector('input');
    if (companyInput) companyInput.required = role === 'contractor';
  }

  showToast(`Account type: ${role.charAt(0).toUpperCase() + role.slice(1)}`, 'info', 1500);
}


/* ============================================================
   WAGE CALCULATOR (auto compute on contractor page)
   ============================================================ */
function initWageCalculator() {
  const daysInput  = $('input[name="days_worked"]');
  const dailyInput = $('input[name="daily_wage"]');
  const deductInput= $('input[name="deductions"]');

  if (!daysInput || !dailyInput) return;

  function compute() {
    const days   = parseFloat(daysInput.value)  || 0;
    const daily  = parseFloat(dailyInput.value) || 0;
    const deduct = parseFloat(deductInput?.value) || 0;
    const total  = days * daily;
    const net    = total - deduct;

    let preview = document.getElementById('wagePreview');
    if (!preview) {
      preview = document.createElement('div');
      preview.id = 'wagePreview';
      preview.style.cssText = 'background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:10px 14px;margin-top:8px;font-size:.83rem;color:#15803d';
      deductInput?.closest('.row')?.insertAdjacentElement('afterend', preview);
    }

    if (days > 0 && daily > 0) {
      preview.innerHTML = `
        <i class="fas fa-calculator me-2"></i>
        <strong>${days}</strong> days × <strong>₹${daily}</strong> = <strong>₹${total.toFixed(0)}</strong>
        ${deduct > 0 ? ` − ₹${deduct.toFixed(0)} deductions =` : ' ='}
        <strong style="font-size:.95rem"> Net: ₹${net.toFixed(0)}</strong>
      `;
      preview.style.display = 'block';
    } else {
      preview.style.display = 'none';
    }
  }

  [daysInput, dailyInput, deductInput].filter(Boolean).forEach(el => el.addEventListener('input', compute));
}


/* ============================================================
   TABLE SEARCH (client-side)
   ============================================================ */
function initTableSearch() {
  const searchInput = $('#tableSearch');
  if (!searchInput) return;

  searchInput.addEventListener('input', debounce(() => {
    const query = searchInput.value.toLowerCase();
    $$('.table-modern tbody tr').forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(query) ? '' : 'none';
    });
  }, 200));
}


/* ============================================================
   CONFIRMATION DIALOGS
   ============================================================ */
function initConfirmActions() {
  $$('[data-confirm]').forEach(el => {
    el.addEventListener('click', (e) => {
      const msg = el.dataset.confirm || 'Are you sure?';
      if (!confirm(msg)) e.preventDefault();
    });
  });
}


/* ============================================================
   ATTENDANCE STATUS COLORS (inline select)
   ============================================================ */
function initAttendanceSelects() {
  $$('select[name="statuses"]').forEach(sel => {
    function updateColor() {
      const colors = {
        present:  '#DCFCE7',
        absent:   '#FEE2E2',
        half_day: '#FEF9C3',
        leave:    '#DBEAFE',
      };
      sel.style.background = colors[sel.value] || '#fff';
    }
    sel.addEventListener('change', updateColor);
    updateColor();
  });
}


/* ============================================================
   TOPBAR DATE / GREETING
   ============================================================ */
function initTopbar() {
  const now = new Date();
  const hour = now.getHours();
  let greeting = 'Good morning';
  if (hour >= 12 && hour < 17) greeting = 'Good afternoon';
  else if (hour >= 17) greeting = 'Good evening';

  const greetEl = document.getElementById('greetingText');
  if (greetEl) greetEl.textContent = greeting;

  const dateEl = document.getElementById('topbarDate');
  if (dateEl) {
    dateEl.textContent = now.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  }
}


/* ============================================================
   COUNTER ANIMATION (stat cards)
   ============================================================ */
function animateCounters() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseFloat(el.dataset.count || el.textContent.replace(/[^0-9.]/g, ''));
      if (isNaN(target)) return;
      const isINR = el.textContent.includes('₹');
      const isK   = el.textContent.includes('K');
      const duration = 1000;
      const start = performance.now();

      function step(now) {
        const p = Math.min((now - start) / duration, 1);
        const ease = 1 - Math.pow(1 - p, 3); // cubic ease out
        const value = target * ease;
        el.textContent = isINR
          ? '₹' + Math.round(value).toLocaleString('en-IN')
          : isK
          ? Math.round(value) + 'K'
          : Math.round(value).toLocaleString('en-IN');
        if (p < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  $$('.stat-num').forEach(el => {
    const text = el.textContent.trim();
    if (/^[\d₹,.K]+$/.test(text)) observer.observe(el);
  });
}


/* ============================================================
   CHART DEFAULTS (Chart.js global config)
   ============================================================ */
function initChartDefaults() {
  if (typeof Chart === 'undefined') return;

  Chart.defaults.font.family = "'Noto Sans', sans-serif";
  Chart.defaults.font.size   = 12;
  Chart.defaults.color       = '#6B7280';
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.pointStyleWidth = 10;
  Chart.defaults.plugins.legend.labels.padding = 14;
  Chart.defaults.plugins.tooltip.backgroundColor = '#0A1628';
  Chart.defaults.plugins.tooltip.titleFont  = { family: "'Rajdhani', sans-serif", size: 13, weight: 700 };
  Chart.defaults.plugins.tooltip.bodyFont   = { family: "'Noto Sans', sans-serif", size: 12 };
  Chart.defaults.plugins.tooltip.padding    = 12;
  Chart.defaults.plugins.tooltip.cornerRadius = 8;
  Chart.defaults.scale.grid.color = '#F3F4F6';
  Chart.defaults.scale.border.display = false;
}


/* ============================================================
   PASSWORD TOGGLE
   ============================================================ */
function initPasswordToggle() {
  $$('.password-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.closest('.password-wrap')?.querySelector('input');
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.innerHTML = isPass ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>';
    });
  });
}


/* ============================================================
   FORM VALIDATION HELPERS
   ============================================================ */
function initFormValidation() {
  $$('form[data-validate]').forEach(form => {
    form.addEventListener('submit', (e) => {
      let valid = true;
      $$('[required]', form).forEach(field => {
        if (!field.value.trim()) {
          field.classList.add('is-invalid');
          valid = false;
        } else {
          field.classList.remove('is-invalid');
        }
      });
      if (!valid) {
        e.preventDefault();
        showToast('Please fill all required fields', 'warning');
      }
    });
  });

  // Remove error class on input
  $$(input => input.classList.contains('is-invalid'))?.forEach?.(input => {
    input.addEventListener('input', () => input.classList.remove('is-invalid'));
  });
}


/* ============================================================
   AADHAAR MASK (display only)
   ============================================================ */
function maskAadhaar(number) {
  if (!number || number.length < 4) return '—';
  return '•••• •••• ' + number.slice(-4);
}


/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  initSidebar();
  initAlerts();
  initPhotoUpload();
  initAadhaarInput();
  initKYCForm();
  initWageCalculator();
  initTableSearch();
  initConfirmActions();
  initAttendanceSelects();
  initTopbar();
  animateCounters();
  initChartDefaults();
  initPasswordToggle();
  initFormValidation();

  // Set today's date on all date inputs that are empty and marked data-today
  $$('input[data-today]').forEach(el => {
    if (!el.value) el.value = new Date().toISOString().split('T')[0];
  });
});

// Expose globally needed functions
window.selectRole = selectRole;
window.showToast  = showToast;
window.maskAadhaar = maskAadhaar;
