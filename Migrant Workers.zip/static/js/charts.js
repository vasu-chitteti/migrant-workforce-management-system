/**
 * MigrantWorks — charts.js
 * Chart.js helper functions and chart builders
 */

'use strict';

const CHART_PALETTE = [
  '#FF6B00', '#0A1628', '#059669', '#7C3AED',
  '#d97706', '#dc2626', '#2563eb', '#0891b2',
  '#65a30d', '#db2777', '#ea580c', '#0284c7'
];

const CHART_SAFFRON = '#FF6B00';
const CHART_NAVY    = '#0A1628';

/* ── Helper: get canvas context safely ── */
function getCtx(id) {
  const el = document.getElementById(id);
  return el ? el.getContext('2d') : null;
}

/* ── Doughnut / Pie chart ── */
function buildDoughnut(canvasId, labels, data, options = {}) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: CHART_PALETTE,
        borderWidth: 3,
        borderColor: '#fff',
        hoverBorderWidth: 3,
        hoverOffset: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      cutout: '62%',
      plugins: {
        legend: {
          position: options.legendPosition || 'right',
          labels: { font: { size: 11 }, padding: 10 }
        },
        tooltip: {
          callbacks: {
            label: (ctx) => ` ${ctx.label}: ${ctx.parsed} workers`
          }
        }
      },
      ...options
    }
  });
}

/* ── Horizontal bar chart ── */
function buildHorizontalBar(canvasId, labels, data, color = CHART_NAVY, options = {}) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: color,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, ticks: { font: { size: 11 } } },
        y: { ticks: { font: { size: 11 } } }
      },
      ...options
    }
  });
}

/* ── Vertical bar chart ── */
function buildBar(canvasId, labels, data, color = CHART_SAFFRON, label = '', options = {}) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  return new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label,
        data,
        backgroundColor: color,
        borderRadius: 8,
        borderSkipped: false,
        hoverBackgroundColor: color + 'CC',
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: !!label } },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 } } },
        y: { beginAtZero: true, ticks: { font: { size: 11 } } }
      },
      ...options
    }
  });
}

/* ── Line chart ── */
function buildLine(canvasId, labels, datasets, options = {}) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  const builtDatasets = datasets.map((ds, i) => ({
    label: ds.label || '',
    data:  ds.data,
    borderColor: ds.color || CHART_PALETTE[i],
    backgroundColor: (ds.color || CHART_PALETTE[i]) + '18',
    fill: ds.fill !== undefined ? ds.fill : true,
    tension: 0.4,
    pointRadius: 4,
    pointHoverRadius: 7,
    pointBackgroundColor: ds.color || CHART_PALETTE[i],
    borderWidth: 2.5,
  }));

  return new Chart(ctx, {
    type: 'line',
    data: { labels, datasets: builtDatasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: datasets.length > 1 }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 } } },
        y: { beginAtZero: true, ticks: { font: { size: 11 } } }
      },
      ...options
    }
  });
}

/* ── Stacked bar chart ── */
function buildStackedBar(canvasId, labels, datasets, options = {}) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  const builtDatasets = datasets.map((ds, i) => ({
    label: ds.label,
    data: ds.data,
    backgroundColor: ds.color || CHART_PALETTE[i],
    borderRadius: i === datasets.length - 1 ? { topLeft: 6, topRight: 6 } : 0,
    borderSkipped: false,
  }));

  return new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: builtDatasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { position: 'top' } },
      scales: {
        x: { stacked: true, grid: { display: false }, ticks: { font: { size: 11 } } },
        y: { stacked: true, ticks: { font: { size: 11 } } }
      },
      ...options
    }
  });
}

/* ── Gauge / Half doughnut ── */
function buildGauge(canvasId, value, max, color = CHART_SAFFRON) {
  const ctx = getCtx(canvasId);
  if (!ctx) return null;

  const pct = Math.min(value / max, 1);

  return new Chart(ctx, {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [pct, 1 - pct],
        backgroundColor: [color, '#F3F4F6'],
        borderWidth: 0,
        circumference: 180,
        rotation: -90,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      cutout: '70%',
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false }
      }
    }
  });
}

/* ── KYC pie (verified vs pending vs failed) ── */
function buildKYCPie(canvasId, verified, pending, failed) {
  return buildDoughnut(
    canvasId,
    ['Verified', 'Pending', 'Failed/Rejected'],
    [verified, pending, failed],
    { legendPosition: 'bottom' }
  );
}

/* ── Attendance summary bar ── */
function buildAttendanceSummary(canvasId, labels, present, absent, halfday) {
  return buildStackedBar(canvasId, labels, [
    { label: 'Present',  data: present,  color: '#86EFAC' },
    { label: 'Half Day', data: halfday,  color: '#FDE68A' },
    { label: 'Absent',   data: absent,   color: '#FCA5A5' },
  ]);
}

/* ── Wage trend line ── */
function buildWageTrend(canvasId, labels, data) {
  return buildLine(canvasId, labels, [
    { label: 'Net Wages Paid (₹)', data, color: '#059669', fill: true }
  ]);
}

/* ── Registration trend ── */
function buildRegistrationTrend(canvasId, labels, data) {
  return buildLine(canvasId, labels, [
    { label: 'New Registrations', data, color: CHART_SAFFRON, fill: true }
  ]);
}

/* ── Export charts to PNG ── */
function exportChart(chartInstance, filename = 'chart.png') {
  const link = document.createElement('a');
  link.href     = chartInstance.canvas.toDataURL('image/png');
  link.download = filename;
  link.click();
}

// Export global
window.MW_Charts = {
  buildDoughnut,
  buildHorizontalBar,
  buildBar,
  buildLine,
  buildStackedBar,
  buildGauge,
  buildKYCPie,
  buildAttendanceSummary,
  buildWageTrend,
  buildRegistrationTrend,
  exportChart,
  PALETTE: CHART_PALETTE
};
